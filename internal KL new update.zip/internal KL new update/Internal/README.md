# Fortnite-Internal-Updated
fortnite internal cheat updated to 27.00 (CHAPTER 4)

If the cheat stops working after update change offsets in sdk.h

Not all injectors work but face injector v2 should (although it only works on BE so find something different for EAC)
