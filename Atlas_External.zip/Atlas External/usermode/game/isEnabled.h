#pragma once

bool aimbot = false;
bool pred = false;
bool vischeck = false;
bool trig = false;
bool fovcircle = false;
bool head = false;
bool neck = false;
bool chest = false;
float smoothing = 1.f;
float aimdistance = 100.f;
int fovSize = 25;
int aimkey;
int trigkey;

bool boxes = false;
bool cornerbox = false;
bool filledboxes = false;
bool skeleton = false;
bool snaplines = false;
float espdistance = 100.f;
float boxthick = 1;
float skelethick = 1;