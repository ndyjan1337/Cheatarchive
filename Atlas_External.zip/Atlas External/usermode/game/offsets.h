#pragma once

enum bone : int
{
    HumanBase = 0,
    HumanPelvis = 2,
    HumanHead = 110,
    HumanLowerHead = 106,
    HumanChest = 65
};

// offsets were updated like last season lmao
namespace offsets {
    uintptr_t UWorld = 0x126CF528;
    uintptr_t GObjects = 0x1260C5A0;
    uintptr_t GNames = 0x10E400C0;
    uintptr_t Levels = 0x178;
    uintptr_t AActors = 0xA0;
    uintptr_t Mesh = 0x318;
    uintptr_t RootComponent = 0x198;
    uintptr_t ComponentToWorld = 0x1c0;
    uintptr_t PlayerController = 0x30;
    uintptr_t LocalPlayers = 0x38;
    uintptr_t OwningGameInstance = 0x1D8;
    uintptr_t GameState = 0x160;
    uintptr_t PersistentLevel = 0x30;
    uintptr_t PawnPrivate = 0x308;
    uintptr_t bIsABot = 0x29A;
    uintptr_t TeamIndex = 0x1211;
    uintptr_t CurrentWeapon = 0xA68;
    uintptr_t WeaponData = 0x4F0;
    uintptr_t SkeletalMesh = 0x540;
    uintptr_t PlayerArray = 0x2A8;
    uintptr_t BoneArray = 0x5B0;
    uintptr_t PlayerState = 0x2B0;
    uintptr_t AcknowledgedPawn = 0x338;
    uintptr_t Platform = 0x438;
    uintptr_t RelativeLocation = 0x120;
    uintptr_t fLastSubmitTime = 0x2E8;
    uintptr_t fLastRenderTimeOnScreen = 0x2F0;
}