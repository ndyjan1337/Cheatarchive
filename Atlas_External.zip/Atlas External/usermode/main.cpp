#include "driver.h"
#include "keyauth/skStr.h"
#include "keyauth/auth.hpp"
#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx9.h"
#include "imgui/imgui_impl_win32.h"
#include "directx9/d3dx9.h"
#include "other/mouse.hpp"
#include "other/xor.hpp"
#include "keyauth/utils.hpp"
#include "game/isEnabled.h"
#include "other/keybinds.h"
#include "game/utilities.hpp"

#include <iostream>
#include <string>
#include <vector>
#include <Windows.h>
#include <dwmapi.h>
#include <stdio.h>
#include <thread>

#pragma comment(lib, "urlmon.lib")

using namespace std;
using namespace KeyAuth;

auto name = skCrypt("NAME");
auto ownerid = skCrypt("OWNERID");
auto secret = skCrypt("SECRET");
auto version = skCrypt("1.0");
auto url = skCrypt("https://keyauth.win/api/1.2/");

api KeyAuthApp(name.decrypt(), ownerid.decrypt(), secret.decrypt(), version.decrypt(), url.decrypt());

ImFont* Font;

LPDIRECT3DDEVICE9 Device = NULL;
D3DPRESENT_PARAMETERS D3DP;
LPDIRECT3DVERTEXBUFFER9 Buffer = NULL;
IDirect3D9Ex* Object = NULL;

HWND hwnd = NULL;
HWND Window = NULL;

RECT FN = { NULL };

int Width;
int Height;

int tab = 0;

DWORD CenterX;
DWORD CenterY;

const MARGINS Margin = { -1 };

MSG Message;

bool Show = true;
bool autoLogin = false;
bool if0 = false;

std::vector<entity> entity_list;
std::vector<entity> temporary_entity_list;

void consoleshittomakelookcleanithink() {
	SetConsoleTitle("P2C NAME");

	SetLayeredWindowAttributes(GetConsoleWindow(), 0, 200, LWA_ALPHA);
	SetWindowPos(GetConsoleWindow(), NULL, 0, 0, 300, 250, SWP_NOMOVE | SWP_NOZORDER);

	HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;

	GetConsoleScreenBufferInfo(console, &csbi);
	COORD bar = {
		csbi.srWindow.Right - csbi.srWindow.Left + 1,
		csbi.srWindow.Bottom - csbi.srWindow.Top + 1
	};

	if (console == 0) {
		std::cout << "this wasnt supposed to happen reopen the exe.";
		system("pause");
		exit(1);
	}
	else {
		SetConsoleScreenBufferSize(console, bar);
	}
}

void DrawBox(int x, int y, int w, int h, ImColor color, int thickness) {
	ImDrawList* Drawlist = ImGui::GetOverlayDrawList();

	Drawlist->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), color, 0.0f, 0, thickness);
}

void DrawCorneredBox(int x, int y, int w, int h, ImColor color, int thickness) {

	ImDrawList* Drawlist = ImGui::GetOverlayDrawList();

	float line_w = (w / 8);
	float line_h = (h / 8);
	Drawlist->AddLine(ImVec2(x, y), ImVec2(x, y + line_h), color, thickness);
	Drawlist->AddLine(ImVec2(x, y), ImVec2(x + line_w, y), color, thickness);
	Drawlist->AddLine(ImVec2(x + w - line_w, y), ImVec2(x + w, y), color, thickness);
	Drawlist->AddLine(ImVec2(x + w, y), ImVec2(x + w, y + line_h), color, thickness);
	Drawlist->AddLine(ImVec2(x, y + h - line_h), ImVec2(x, y + h), color, thickness);
	Drawlist->AddLine(ImVec2(x, y + h), ImVec2(x + line_w, y + h), color, thickness);
	Drawlist->AddLine(ImVec2(x + w - line_w, y + h), ImVec2(x + w, y + h), color, thickness);
	Drawlist->AddLine(ImVec2(x + w, y + h - line_h), ImVec2(x + w, y + h), color, thickness);
}

void DrawFilledBox(int x, int y, int w, int h, ImColor color) {
	ImDrawList* Drawlist = ImGui::GetOverlayDrawList();

	color.Value.w = 0.5f;

	Drawlist->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), color, 0.0f, 0);
}

void DrawSkeleton(uintptr_t skeletal_mesh) {
	Vector3 bonePositions[] = {
		GetBoneWithRotation(skeletal_mesh, 110),
		GetBoneWithRotation(skeletal_mesh, 2),
		GetBoneWithRotation(skeletal_mesh, 67),
		GetBoneWithRotation(skeletal_mesh, 9),
		GetBoneWithRotation(skeletal_mesh, 38),
		GetBoneWithRotation(skeletal_mesh, 10),
		GetBoneWithRotation(skeletal_mesh, 39),
		GetBoneWithRotation(skeletal_mesh, 11),
		GetBoneWithRotation(skeletal_mesh, 40),
		GetBoneWithRotation(skeletal_mesh, 78),
		GetBoneWithRotation(skeletal_mesh, 71),
		GetBoneWithRotation(skeletal_mesh, 79),
		GetBoneWithRotation(skeletal_mesh, 72),
		GetBoneWithRotation(skeletal_mesh, 74),
		GetBoneWithRotation(skeletal_mesh, 81)
	};

	Vector2 bonePositionsOut[16];
	for (int i = 0; i < 16; ++i) {
		bonePositionsOut[i] = WorldToScreen2(bonePositions[i]);
	}

	static ImColor color;

	if (vischeck) {
		if (IsVisible(skeletal_mesh))
		{
			color = ImColor(128, 0, 128, 255);
		}
		else
		{
			color = ImColor(255, 0, 0, 255);
		}
	}
	else {
		color = ImColor(128, 0, 128, 255);
	}

	ImDrawList* Drawlist = ImGui::GetOverlayDrawList();

	Drawlist->AddLine(ImVec2(bonePositionsOut[1].x, bonePositionsOut[1].y), ImVec2(bonePositionsOut[2].x, bonePositionsOut[2].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[3].x, bonePositionsOut[3].y), ImVec2(bonePositionsOut[2].x, bonePositionsOut[2].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[4].x, bonePositionsOut[4].y), ImVec2(bonePositionsOut[2].x, bonePositionsOut[2].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[5].x, bonePositionsOut[5].y), ImVec2(bonePositionsOut[3].x, bonePositionsOut[3].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[6].x, bonePositionsOut[6].y), ImVec2(bonePositionsOut[4].x, bonePositionsOut[4].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[5].x, bonePositionsOut[5].y), ImVec2(bonePositionsOut[7].x, bonePositionsOut[7].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[6].x, bonePositionsOut[6].y), ImVec2(bonePositionsOut[8].x, bonePositionsOut[8].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[10].x, bonePositionsOut[10].y), ImVec2(bonePositionsOut[1].x, bonePositionsOut[1].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[9].x, bonePositionsOut[9].y), ImVec2(bonePositionsOut[1].x, bonePositionsOut[1].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[12].x, bonePositionsOut[12].y), ImVec2(bonePositionsOut[10].x, bonePositionsOut[10].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[11].x, bonePositionsOut[11].y), ImVec2(bonePositionsOut[9].x, bonePositionsOut[9].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[13].x, bonePositionsOut[13].y), ImVec2(bonePositionsOut[12].x, bonePositionsOut[12].y), color, skelethick);
	Drawlist->AddLine(ImVec2(bonePositionsOut[14].x, bonePositionsOut[14].y), ImVec2(bonePositionsOut[11].x, bonePositionsOut[11].y), color, skelethick);
}

entity cached_actors{};

bool isworld = false;
DWORD UpdateThread(LPVOID in)
{
	while (1)
	{
		temporary_entity_list.clear();

		pointer->uworld = read<uintptr_t>(virtualaddy + offsets::UWorld);
		if (isworld && pointer->uworld != 0)
		{
			std::cout << " [uworld] " << pointer->uworld << "\n";
			isworld = true;
		}
		pointer->game_instance = read<uintptr_t>(pointer->uworld + offsets::OwningGameInstance);
		pointer->levels = read<uintptr_t>(pointer->levels + offsets::Levels);
		pointer->game_state = read<uintptr_t>(pointer->uworld + offsets::GameState);
		pointer->local_player = read<uintptr_t>(read<uintptr_t>(pointer->game_instance + offsets::LocalPlayers));
		pointer->player_controller = read<uintptr_t>(pointer->local_player + offsets::PlayerController);
		pointer->acknowledged_pawn = read<uintptr_t>(pointer->player_controller + offsets::AcknowledgedPawn);
		pointer->current_weapon = read<uintptr_t>(pointer->acknowledged_pawn + offsets::CurrentWeapon);
		pointer->skeletal_mesh = read<uintptr_t>(pointer->acknowledged_pawn + offsets::SkeletalMesh);
		pointer->player_state = read<uintptr_t>(pointer->acknowledged_pawn + offsets::PlayerState);
		pointer->root_component = read<uintptr_t>(pointer->acknowledged_pawn + offsets::RootComponent);
		pointer->team_index = read<int>(pointer->player_state + offsets::TeamIndex);
		pointer->relative_location = read<FVector>(pointer->root_component + offsets::RelativeLocation);
		pointer->player_array = read<uintptr_t>(pointer->game_state + offsets::PlayerArray);

		pointer->player_array_size = read<int>(pointer->game_state + (offsets::PlayerArray + sizeof(uintptr_t)));

		for (int i = 0; i < pointer->player_array_size; ++i) {
			auto player_state = read<uintptr_t>(pointer->player_array + (i * sizeof(uintptr_t)));
			auto current_actor = read<uintptr_t>(player_state + offsets::PawnPrivate);

			if (current_actor == pointer->acknowledged_pawn) continue;
			auto skeletalmesh = read<uintptr_t>(current_actor + offsets::SkeletalMesh);

			pointer->mesh = read<uint64_t>(current_actor + offsets::Mesh);

			if (!skeletalmesh) continue;

			auto base_bone = GetBoneLocation(skeletalmesh, bone::HumanBase);
			if (base_bone.x == 0 && base_bone.y == 0 && base_bone.z == 0) continue;

			if (!InScreen(WorldToScreen(GetBoneLocation(skeletalmesh, bone::HumanPelvis)))) continue;

			auto is_despawning = (read<char>(current_actor + 0x758) >> 3);

			if (is_despawning) continue;

			if (pointer->acknowledged_pawn)
			{
				auto team_index = read<int>(player_state + offsets::TeamIndex);
				if (pointer->team_index == team_index) continue;
			}
			
			cached_actors.actor = current_actor;
			cached_actors.skeletal_mesh = read<uintptr_t>(current_actor + offsets::SkeletalMesh);
			cached_actors.root_component = read<uintptr_t>(current_actor + offsets::RootComponent);
			cached_actors.player_state = read<uintptr_t>(current_actor + offsets::PlayerState);
			cached_actors.team_index = read<int>(cached_actors.player_state + offsets::TeamIndex);
			temporary_entity_list.push_back(cached_actors);
		}

		entity_list.clear();
		entity_list = temporary_entity_list;

		Sleep(200);
	}
}

void trigger() {
	INPUT    Input = { 0 };

	Input.type = INPUT_MOUSE;
	Input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
	::SendInput(1, &Input, sizeof(INPUT));

	std::this_thread::sleep_for(std::chrono::milliseconds(11));
	::ZeroMemory(&Input, sizeof(INPUT));
	Input.type = INPUT_MOUSE;
	Input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
	::SendInput(1, &Input, sizeof(INPUT));
}

void GameThread() {
	UpdateCamera();

	auto root_location = GetBoneLocation(cached_actors.skeletal_mesh, bone::HumanBase);
	auto root_screen = WorldToScreen(root_location);
	auto head_location = GetBoneLocation(cached_actors.skeletal_mesh, bone::HumanHead);
	auto head_screen = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, bone::HumanHead));
	auto head_screen1 = GetBoneLocation(cached_actors.skeletal_mesh, bone::HumanHead);

	FVector2d head_box = WorldToScreen(FVector(head_screen1.x, head_screen1.y, head_screen1.z + 15));
	FVector2d head_2d = WorldToScreen(FVector(head_location.x, head_location.y, head_location.z + 20));

	float box_height = abs(head_screen.y - root_screen.y);
	float box_width = box_height * 0.50f;
	float distance = camera::location.Distance(root_location) / 100;

	if (fovcircle) {
		ImGui::GetOverlayDrawList()->AddCircle(ImVec2(GetSystemMetrics(SM_CXSCREEN) / 2, GetSystemMetrics(SM_CYSCREEN) / 2), fovSize, ImColor(255, 0, 255, 255), 33, 1);
	}

	if (trig) {
		if (&vischeck) {
			if (IsVisible(cached_actors.skeletal_mesh)) {
				if (GetAsyncKeyState(trigkey)) {
					std::thread t(trigger);
					t.join();
				}
			}
		}
		else {
			if (GetAsyncKeyState(trigkey)) {
				std::thread t(trigger);
				t.join();
			}
		}
	}

	if (boxes) {
		if (vischeck)
		{
			if (IsVisible(cached_actors.skeletal_mesh)) {
				auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

				float CornerHeight = abs(head_box.y - root_box1.y);
				float CornerWidth = box_height * 0.50f;

				DrawBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(128, 0, 128, 255), boxthick);
			}
			else {
				auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

				float CornerHeight = abs(head_box.y - root_box1.y);
				float CornerWidth = box_height * 0.50f;

				DrawBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(255, 0, 0, 255), boxthick);
			}
		}
		else {
			auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

			float CornerHeight = abs(head_box.y - root_box1.y);
			float CornerWidth = box_height * 0.50f;

			DrawBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(128, 0, 128, 255), boxthick);
		}
	}

	if (cornerbox) {
		if (vischeck)
		{
			if (IsVisible(cached_actors.skeletal_mesh)) {
				auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

				float CornerHeight = abs(head_box.y - root_box1.y);
				float CornerWidth = box_height * 0.50f;

				DrawCorneredBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(128, 0, 128, 255), boxthick);
			}
			else {
				auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

				float CornerHeight = abs(head_box.y - root_box1.y);
				float CornerWidth = box_height * 0.50f;

				DrawCorneredBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(255, 0, 0, 255), boxthick);
			}
		}
		else {
			auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

			float CornerHeight = abs(head_box.y - root_box1.y);
			float CornerWidth = box_height * 0.50f;

			DrawCorneredBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(128, 0, 128, 255), boxthick);
		}
	}

	if (filledboxes) {
		if (vischeck)
		{
			if (IsVisible(cached_actors.skeletal_mesh)) {
				auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

				float CornerHeight = abs(head_box.y - root_box1.y);
				float CornerWidth = box_height * 0.50f;

				DrawFilledBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(128, 0, 128, 255));
			}
			else {
				auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

				float CornerHeight = abs(head_box.y - root_box1.y);
				float CornerWidth = box_height * 0.50f;

				DrawFilledBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(255, 0, 0, 255));
			}
		}
		else {
			auto root_box1 = WorldToScreen(GetBoneLocation(cached_actors.skeletal_mesh, 0));

			float CornerHeight = abs(head_box.y - root_box1.y);
			float CornerWidth = box_height * 0.50f;

			DrawFilledBox(head_box.x - (CornerWidth / 2), head_box.y, CornerWidth, CornerHeight, ImColor(128, 0, 128, 255));
		}
	}

	if (skeleton) {
		DrawSkeleton(offsets::SkeletalMesh);
	}

	if (snaplines) {
		if (vischeck)
		{
			if (IsVisible(cached_actors.skeletal_mesh))
			{
				ImGui::GetOverlayDrawList()->AddLine(ImVec2(GetSystemMetrics(SM_CXSCREEN) / 2, 0), ImVec2(head_2d.x, head_2d.y), ImColor(128, 0, 128, 255), 2.f);
			}
			else {
				ImGui::GetOverlayDrawList()->AddLine(ImVec2(GetSystemMetrics(SM_CXSCREEN) / 2, 0), ImVec2(head_2d.x, head_2d.y), ImColor(255, 0, 0, 255), 2.f);
			}
		}
		else {
			ImGui::GetOverlayDrawList()->AddLine(ImVec2(GetSystemMetrics(SM_CXSCREEN) / 2, 0), ImVec2(head_2d.x, head_2d.y), ImColor(128, 0, 128, 255), 2.f);
		}
	}
}

void ShutdownGUI() {
	Buffer->Release();
	Device->Release();
	Object->Release();

	DestroyWindow(Window);
	UnregisterClass("Video Player Device", NULL);
}

void SetTarget()
{
	while (true)
	{
		if (hwnd)
		{
			ZeroMemory(&FN, sizeof(FN));
			GetWindowRect(hwnd, &FN);
			Width = FN.right - FN.left;
			Height = FN.bottom - FN.top;
			DWORD dwStyle = GetWindowLong(hwnd, GWL_STYLE);

			if (dwStyle & WS_BORDER)
			{
				FN.top += 32;
				Height -= 39;
			}

			CenterX = Width / 2;
			CenterY = Height / 2;
			MoveWindow(Window, FN.left, FN.top, Width, Height, true);
		}
		else
		{
			exit(0);
		}
	}
}

LRESULT CALLBACK WinProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
	case WM_DESTROY:
		ShutdownGUI();
		PostQuitMessage(0);
		exit(4);
		break;
	case WM_SIZE:
		if (Device != NULL && wParam != SIZE_MINIMIZED)
		{
			ImGui_ImplDX9_InvalidateDeviceObjects();
			D3DP.BackBufferWidth = LOWORD(lParam);
			D3DP.BackBufferHeight = HIWORD(lParam);
			HRESULT hr = Device->Reset(&D3DP);
			if (hr == D3DERR_INVALIDCALL)
				IM_ASSERT(0);
			ImGui_ImplDX9_CreateDeviceObjects();
		}
		break;
	default:
		return DefWindowProc(hWnd, Message, wParam, lParam);
	}
}

void CreateGUIWindow() {
	CreateThread(0, 0, (LPTHREAD_START_ROUTINE)SetTarget, 0, 0, 0);

	WNDCLASS windowClass = { 0 };
	windowClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	windowClass.hInstance = NULL;
	windowClass.lpfnWndProc = WinProc;
	windowClass.lpszClassName = "Video Player Device";
	windowClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&windowClass);

	Window = CreateWindow("Video Player Device",
		NULL,
		WS_POPUP,
		0,
		0,
		GetSystemMetrics(SM_CXSCREEN),
		GetSystemMetrics(SM_CYSCREEN),
		NULL,
		NULL,
		NULL,
		NULL);

	ShowWindow(Window, SW_SHOW);

	DwmExtendFrameIntoClientArea(Window, &Margin);
	SetWindowLongA(Window, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_LAYERED);
	UpdateWindow(Window);
}

void InitD3D()
{
	if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &Object)))
		exit(3);

	ZeroMemory(&D3DP, sizeof(D3DP));
	D3DP.BackBufferWidth = Width;
	D3DP.BackBufferHeight = Height;
	D3DP.BackBufferFormat = D3DFMT_A8R8G8B8;
	D3DP.MultiSampleQuality = D3DMULTISAMPLE_NONE;
	D3DP.AutoDepthStencilFormat = D3DFMT_D16;
	D3DP.SwapEffect = D3DSWAPEFFECT_DISCARD;
	D3DP.EnableAutoDepthStencil = TRUE;
	D3DP.hDeviceWindow = Window;
	D3DP.Windowed = TRUE;

	Object->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, Window, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &D3DP, &Device);

	IMGUI_CHECKVERSION();

	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	(void)io;

	ImGui_ImplWin32_Init(Window);
	ImGui_ImplDX9_Init(Device);

	ImGui::StyleColorsClassic();
	ImGuiStyle* style = &ImGui::GetStyle();

	style->WindowMinSize = ImVec2(350, 240);
	style->WindowBorderSize = 0;

	style->ChildRounding = 0;
	style->FrameRounding = 0;
	style->ScrollbarRounding = 0;
	style->GrabRounding = 0;
	style->PopupRounding = 0;
	style->WindowRounding = 0;

	style->Colors[ImGuiCol_WindowBg] = ImColor(20, 20, 30, 255);
	style->Colors[ImGuiCol_Border] = ImColor(40, 40, 50, 255);
	style->Colors[ImGuiCol_FrameBg] = ImColor(30, 30, 40, 255);
	style->Colors[ImGuiCol_FrameBgHovered] = ImColor(70, 70, 80, 255);
	style->Colors[ImGuiCol_FrameBgActive] = ImColor(255, 255, 255, 255);
	style->Colors[ImGuiCol_CheckMark] = ImColor(128, 0, 128, 255);
	style->Colors[ImGuiCol_SliderGrab] = ImColor(100, 0, 100, 255);
	style->Colors[ImGuiCol_SliderGrabActive] = ImColor(100, 0, 100, 255);
	style->Colors[ImGuiCol_Button] = ImColor(128, 0, 128, 255);
	style->Colors[ImGuiCol_ButtonHovered] = ImColor(148, 0, 148, 255);
	style->Colors[ImGuiCol_ButtonActive] = ImColor(168, 0, 168, 255);
	style->Colors[ImGuiCol_Separator] = ImColor(89, 3, 247, 255);
	style->Colors[ImGuiCol_TitleBg] = ImColor(20, 20, 30, 255);
	style->Colors[ImGuiCol_TitleBgActive] = ImColor(20, 20, 30, 255);
	style->Colors[ImGuiCol_TitleBgCollapsed] = ImColor(20, 20, 30, 255);

	style->WindowTitleAlign.x = 0.50f;

	XorS(font, "C:\\Windows\\Fonts\\impact.ttf");
	Font = io.Fonts->AddFontFromFileTTF(font.decrypt(), 14.0f, nullptr, io.Fonts->GetGlyphRangesDefault());

	Object->Release();
}

std::string solidfps(float value) {
	std::ostringstream oss;
	oss << std::fixed << std::setprecision(0) << value;
	return oss.str();
}

void DoRender() {
	ImGui_ImplDX9_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	if (Show)
	{
		ImGui::SetNextWindowSize({ 350, 240 });

		ImGui::Begin(("P2C NAME"), 0, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar);
		
		std::string priv = "P2C NAME | " + solidfps(ImGui::GetIO().Framerate) + " FPS";
		ImGui::GetOverlayDrawList()->AddText(ImVec2(22, 24), ImColor(255, 255, 255), priv.c_str());

		ImDrawList* draw;
		draw = ImGui::GetWindowDrawList();
		ImVec2 screenSize = ImGui::GetIO().DisplaySize;
		ImGui::Particles(draw, screenSize);

		ImGui::BeginChild("##ChildIdentifier", ImVec2(335, 205), true, ImGuiWindowFlags_NoScrollbar);
		{
			if (ImGui::Button("Aim", { 65, 25 })) {
				tab = 0;
			}

			ImGui::SameLine();

			if (ImGui::Button("Visuals", { 65, 25 })) {
				tab = 1;
			}

			if (tab == 0) {
				ImGui::SetCursorPos({ 80, 35 });
				ImGui::Text("Aimbot Key");

				ImGui::SetCursorPos({ 80, 50 });
				HotkeyButton(aimkey, ChangeKey, keystatus);

				ImGui::SetCursorPos({ 80, 70 });
				ImGui::Text("Triggerbot Key");

				ImGui::SetCursorPos({ 80, 85 });
				HotKeyButtonn(trigkey, ChangeKeyy, keystatuss);

				ImGui::SetCursorPos({ 215, 35 });
				ImGui::Text("Aimbot Bone");

				ImGui::SetCursorPos({ 215, 53 });
				if (ImGui::Checkbox("Head", &head)) {
					chest = false;
					neck = false;
				}

				ImGui::SetCursorPos({ 215, 71 });
				if (ImGui::Checkbox("Neck", &neck)) {
					head = false;
					chest = false;
				}

				ImGui::SetCursorPos({ 215, 89 });
				if (ImGui::Checkbox("Chest", &chest)) {
					head = false;
					neck = false;
				}

				ImGui::SetCursorPos({ 8, 40 });

				ImGui::Checkbox("Aimbot", &aimbot);
				ImGui::Checkbox("FOV Circle", &fovcircle);
				ImGui::Checkbox("Prediction", &pred);
				ImGui::Checkbox("Vis Check", &vischeck);
				ImGui::Checkbox("Triggerbot", &trig);

				ImGui::SliderFloat("Smoothing", &smoothing, 1, 20);
				ImGui::SliderFloat("Distance", &aimdistance, 100, 300);
				ImGui::SliderInt("FOV Size", &fovSize, 25, 500);
			}

			if (tab == 1) {
				ImGui::SetCursorPos({ 8, 40 });

				if (ImGui::Checkbox("Boxes", &boxes)) {
					cornerbox = false;
					filledboxes = false;
				}

				if (ImGui::Checkbox("Corner Boxes", &cornerbox)) {
					boxes = false;
					filledboxes = false;
				}

				if (ImGui::Checkbox("Filled Boxes", &filledboxes)) {
					boxes = false;
					cornerbox = false;
				}

				ImGui::Checkbox("Skeleton", &skeleton);
				ImGui::Checkbox("Snaplines", &snaplines);

				ImGui::SliderFloat("Distance", &espdistance, 100, 300);
				ImGui::SliderFloat("Box Thickness", &boxthick, 1, 20);
				ImGui::SliderFloat("Skeleton Thickness", &skelethick, 1, 20);
			}
		}

		ImGui::EndChild();
		ImGui::End();
	}

	GameThread();

	ImGui::EndFrame();
	Device->SetRenderState(D3DRS_ZENABLE, false);
	Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	Device->SetRenderState(D3DRS_SCISSORTESTENABLE, false);
	Device->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);

	if (Device->BeginScene() >= 0)
	{
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
		Device->EndScene();
	}

	HRESULT result = Device->Present(NULL, NULL, NULL, NULL);

	if (result == D3DERR_DEVICELOST && Device->TestCooperativeLevel() == D3DERR_DEVICENOTRESET)
	{
		ImGui_ImplDX9_InvalidateDeviceObjects();
		Device->Reset(&D3DP);
		ImGui_ImplDX9_CreateDeviceObjects();
	}
}

void RLoop()
{
	static RECT old_rc;
	ZeroMemory(&Message, sizeof(MSG));

	while (Message.message != WM_QUIT)
	{
		if (PeekMessage(&Message, Window, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessageA(&Message);
		}

		HWND hwnd_active = GetForegroundWindow();

		if (hwnd_active == hwnd) {
			HWND hwndtest = GetWindow(hwnd_active, GW_HWNDPREV);
			SetWindowPos(Window, hwndtest, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		}

		if (GetAsyncKeyState(0x23) & 1)
			exit(8);

		RECT rc;
		POINT xy;

		ZeroMemory(&rc, sizeof(RECT));
		ZeroMemory(&xy, sizeof(POINT));
		GetClientRect(hwnd, &rc);
		ClientToScreen(hwnd, &xy);
		rc.left = xy.x;
		rc.top = xy.y;

		ImGuiIO& io = ImGui::GetIO();
		io.IniFilename = NULL;
		io.ImeWindowHandle = hwnd;
		io.DeltaTime = 1.0f / 60.0f;

		POINT p;
		GetCursorPos(&p);
		io.MousePos.x = p.x - xy.x;
		io.MousePos.y = p.y - xy.y;

		if (GetAsyncKeyState(VK_LBUTTON)) {
			io.MouseDown[0] = true;
			io.MouseClicked[0] = true;
			io.MouseClickedPos[0].x = io.MousePos.x;
			io.MouseClickedPos[0].x = io.MousePos.y;
		}
		else
			io.MouseDown[0] = false;

		if (rc.left != old_rc.left || rc.right != old_rc.right || rc.top != old_rc.top || rc.bottom != old_rc.bottom)
		{
			old_rc = rc;

			Width = rc.right;
			Height = rc.bottom;

			D3DP.BackBufferWidth = Width;
			D3DP.BackBufferHeight = Height;
			SetWindowPos(Window, (HWND)0, xy.x, xy.y, Width, Height, SWP_NOREDRAW);
			Device->Reset(&D3DP);
		}

		DoRender();
	}

	ImGui_ImplDX9_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	DestroyWindow(Window);
}

DWORD ShowThread(LPVOID in)
{
	while (1)
	{
		if (GetAsyncKeyState(VK_INSERT) & 1) {
			Show = !Show;
		}
		Sleep(1);
	}
}

bool didloginshit = false;

void main()
{
	consoleshittomakelookcleanithink(); // comment out if u added the keyauth shit

	// keyauth shit
	/*if (!didloginshit)
	{
		name.clear(); ownerid.clear(); secret.clear(); version.clear(); url.clear();

		consoleshittomakelookcleanithink();

		KeyAuthApp.init();
		if (!KeyAuthApp.response.success) {
			std::cout << " [-] Failed to connect to authentication service.";
			Sleep(1500);
			exit(1);
		}

		if (std::filesystem::exists("key.json"))
		{
			if (!CheckIfJsonKeyExists("key.json", "username"))
			{
				std::string key = ReadFromJson("key.json", "license");
				KeyAuthApp.license(key);
				if (!KeyAuthApp.response.success)
				{
					std::remove("key.json");
					std::cout << skCrypt("\n Response: ") << KeyAuthApp.response.message;
					Sleep(1500);
					exit(1);
				}
				autoLogin = true;
				std::cout << skCrypt(" [+] Auto logged in");
			}
		}

		if (!autoLogin)
		{
			std::cout << skCrypt("\n [1] License Key\n [2] Exit\n\n [+] Option: ");

			int opt;
			std::string key;

			std::cin >> opt;
			switch (opt) {

			case 1:
				std::cout << skCrypt(" [+] Key: ");
				std::cin >> key;
				KeyAuthApp.license(key);
				break;

			case 2:
				exit(1);

			default:
				std::cout << skCrypt("\n [-] Invalid selection.");
				Sleep(1500);
				exit(1);
			}

			if (!KeyAuthApp.response.success) {
				std::cout << skCrypt("\n [-] Authentication failed.");
				Sleep(1500);
				exit(1);
			}
			else {
				WriteToJson("key.json", "license", key, false, "", "");
			}
		}

		didloginshit = true;
	}*/

	system("cls");

	std::cout << skCrypt("\n [1] Load Cheat\n [2] Load Spoofer\n [3] Clean Traces\n\n [+] Option: ");

	int opt;
	std::cin >> opt;

	if (opt == 1)
	{
		if (!mem::find_driver()) {
			cout << " [+] Attempting to load driver..\n";
			// driver mapping code
		}

		if (!mem::find_driver()) {
			std::cout << " [-] Driver failed to load, try again.";
			Sleep(1500);
			exit(1);
		}

		std::cout << " [+] Waiting for FN..\n";

		while (mem::process_id == 0) {
			mem::process_id = mem::find_process("FortniteClient-Win64-Shipping.exe");
		}

		while (hwnd == NULL) {
			XorS(win, "Fortnite  ");
			hwnd = FindWindowA(0, win.decrypt());
			Sleep(100);
		}

		system("cls");

		std::cout << " [+] Found FN!\n";

		virtualaddy = mem::find_image();
		if (!virtualaddy) {
			std::cout << " [-] Failed to get base address.";
			Sleep(1500);
			exit(1);
		}

		system("cls");

		std::cout << " [+] Process ID -> " << mem::process_id << "\n";
		std::cout << " [+] Base Address -> " << virtualaddy << "\n";

		LPDWORD athreadID = NULL;
		LPDWORD bthreadID = NULL;

		HANDLE aThread = CreateThread(NULL, 0, ShowThread, NULL, 0, athreadID);
		HANDLE bThread = CreateThread(NULL, 0, UpdateThread, NULL, 0, bthreadID);

		MouseInterface();

		CreateGUIWindow();
		InitD3D();
		RLoop();
		ShutdownGUI();
	}
	else if (opt == 2) {
		cout << " [+] Attempting to load driver..\n";
		// spoof load driver

		cout << " [+] Spoofed!\n";
		Sleep(1500);
		exit(1);
	}
	else if (opt == 3) {
		// cleaner

		std::cout << " [+] Cleaned files!";
		Sleep(1000);
		main();
	}
	else {
		std::cout << skCrypt("\n [-] Invalid selection.");
		Sleep(1500);
		exit(1);
	}
}