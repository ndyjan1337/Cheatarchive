﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

using Newtonsoft.Json;

namespace NezurAimbot.Interface.Loader
{
    public partial class Loader : Window
    {

        public Loader() => InitializeComponent();
       

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://1cheats.com/store/product/41-nezur-key-bypass-lifetime-license/",
                UseShellExecute = true
            });
            using (WebClient Http = new WebClient { })
            {
                if (LocalVersion != Http.DownloadString("https://nezur.net/version.txt"))
                {
                    MessageBox.Show("It Appears You're Using An Older Version Of Nezur, Please Visit Our Discord Or https://nezur.net To Download Our Latest Release.", "Nezur",
                        MessageBoxButton.OK, MessageBoxImage.Error);

                    Process.Start(new ProcessStartInfo
                    {
                        FileName = "https://nezur.net",
                        UseShellExecute = true
                    });

                    this.Close();
                }
            }

            KeyStep.Visibility = Visibility.Visible;
            DownloadStep.Visibility = Visibility.Hidden;

            string[] Directories = new string[] { "Bin", "Logs", "Bin\\Config", "Bin\\Images", "Bin\\Aim", };

            for (int i = 0; i < Directories.Length; ++i)
                Directory.CreateDirectory(Directories[i]);

          

            Main.Visibility = Visibility.Hidden;
            await LoadAnimations();
        }

        private async Task LoadAnimations()
        {
            await Task.Delay(500);
            Main.Visibility = Visibility.Visible;
            await Animations.AnimateVisibility(Main, Visibility.Visible);
            await Animations.AnimateVisibility(Main, Visibility.Visible);
        }

        public async Task DownloadFileAsync(string Url, string Destination, string Name)
        {
            if (File.Exists(Destination) == true)
                return;

            using (WebClient Http = new WebClient { Proxy = null })
            {
                Http.DownloadProgressChanged += (s, e) => DW.Content = $"Downloading {Name} - {e.ProgressPercentage}%";
                
                await Http.DownloadFileTaskAsync(
                    new Uri(Url),
                    Destination);
            }
        }
        public static api KeyAuthApp = new api(
           name: "Nezur",
           ownerid: "2UWe8CI1m7",
           secret: "da0fa5c2ed5edc166033d7296f3343118d8401fd552aafae3b231d896b558dd9",
           version: "1.0"
       );
        private async void Enter_Click(object sender, RoutedEventArgs e)
        {

            KeyAuthApp.init();
            string key = Input.Password;
            KeyAuthApp.license(key);

            if (KeyAuthApp.response.success)
            {
                KeyStep.Visibility = Visibility.Hidden;
                DownloadStep.Visibility = Visibility.Visible;

                await DownloadFileAsync("https://raw.githubusercontent.com/0x9374698765254342/Models/main/Resources/DirectML.dll", "DirectML.dll", "DirectML.dll");
                await DownloadFileAsync("https://raw.githubusercontent.com/0x9374698765254342/Models/main/Resources/onnxruntime.dll", "onnxruntime.dll", "onnxruntime.dll");

                new MainInterface().Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Your key is incorrect!");
            }
        }

        private void Get_Click(object sender, RoutedEventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://key.nezur.net",
                UseShellExecute = true
            });
        }

        private void Discord_Click(object sender, RoutedEventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://discord.gg/nezurai",
                UseShellExecute = true
            });
        }

        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        private void Maximize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = isMaximized ? previousState : WindowState.Maximized;
            isMaximized = !isMaximized;
        }

        private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

        private void Drag(object sender, RoutedEventArgs e) => DragMove();
    }
}