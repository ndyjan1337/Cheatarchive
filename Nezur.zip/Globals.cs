﻿// Windows
global using System.Windows;


// Local
global using static NezurAimbot.Static.Data;