#include <Windows.h>
#include <iostream>

namespace define
{
   bool exploits = false;


   bool SuperDMR = false;
   bool PlayersFly = false;
   bool Collision = false;
   bool instareload = false;
   bool cartp = false;
   bool Speed = false;
   bool boatspeed = false;
   bool carfly = false;
   bool spinbot = false;
   bool fuel = false;
   bool RapidFire = false;
   float niggerfovchanger = 500;
   bool WeaponNULL = false;
   bool first_person = false;
}