﻿#include "win_utils.h"
#include "d3d9_x.h"
#include "xor.hpp"
#include <dwmapi.h>
#include <vector>
#include "skStr.h"
#include <string>
#include <iostream>
#include "skStr.h"
#include <Windows.h>
#include <string>
#include <fstream>
#include "offsets.h"
#include <cstdint>
#include <filesystem>
#include <Mmsystem.h>
#include <mciapi.h>
#include <shobjidl_core.h>
#include <direct.h>
#include <urlmon.h>
#include <random>
#include <tlhelp32.h>
#include <winioctl.h>
#include <msxml.h>    
#include <atomic>
#include <mutex>
#include "lazy.h"
#include "FVector.h"
#include "driver.h"
#include "drawings.h"
#include "sdk.h"
#include <lmcons.h>
#include "features.h"
#include "overlay.h"
#include "x.hpp"

#define vk_9 0x39

bool ShowMenu = true;

DWORD_PTR Uworld;
DWORD_PTR LocalPawn;
DWORD_PTR PlayerState;
DWORD_PTR Localplayer;
DWORD_PTR Rootcomp;
DWORD_PTR PlayerController;
DWORD_PTR Persistentlevel;
DWORD_PTR PlayerCamManager;

Vector3 localactorpos;

uint64_t TargetPawn;
int localplayerID;

D3DPRESENT_PARAMETERS d3dpp;



int CurrentActorId;



//static void xCreateWindow();
static void xInitD3d();
void actorloop();
static void xMainLoop();
static void xShutdown();
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);



IDirect3D9Ex* p_Object = NULL;
static LPDIRECT3DDEVICE9 D3dDevice = NULL;
static LPDIRECT3DVERTEXBUFFER9 TriBuf = NULL;



std::uintptr_t process_find(const std::string& name)
{
	const auto snap = LI_FN(CreateToolhelp32Snapshot).safe()(TH32CS_SNAPPROCESS, 0);
	if (snap == INVALID_HANDLE_VALUE) {
		return 0;
	}

	PROCESSENTRY32 proc_entry{};
	proc_entry.dwSize = sizeof proc_entry;

	auto found_process = false;
	if (!!LI_FN(Process32First).safe()(snap, &proc_entry)) {
		do {
			if (name == proc_entry.szExeFile) {
				found_process = true;
				break;
			}
		} while (!!LI_FN(Process32Next).safe()(snap, &proc_entry));
	}

	LI_FN(CloseHandle).safe()(snap);
	return found_process
		? proc_entry.th32ProcessID
		: 0;
}

using namespace std;


int main(int argc, const char* argv[])
{

	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	system("cls");


	SetConsoleTextAttribute(hConsole, 11);
	TCHAR name[UNLEN + 1];
	DWORD size = UNLEN + 1;
	SetConsoleTitle(("Updated Base | security#7529 (aware)"));


	system("cls");

	printf("\n\n   Updated Base");

	system("start https://discord.gg/sFcDNCMJzU");
	system("start https://github.com/aware0000");


	Sleep(3000);


	std::cout << ("\n\n   Waiting for Fortnite") << std::endl;

	while (hwnd == NULL)
	{

		XorS(wind, "Fortnite  ");
		hwnd = FindWindowA(0, wind.decrypt());
		Sleep(100);
	}

	while (true) {
		auto FnCheck = FindWindowA("UnrealWindow", "Fortnite  ");
		if (FnCheck)
			break;
	}

	printf("\n\n   Press F2 In Lobby");
	while (true)
	{
		if (GetAsyncKeyState(VK_F2))
		{
			break;
			Beep(300, 300);
		}
	}

	driver->process_id = process_find("FortniteClient-Win64-Shipping.exe");

	driver->get_driver_handle();

	if (!driver->process_id) {
		std::cout << ("\n\n   Driver Error: Failed to get games PID please restart and remap driver");
		Sleep(2000);
		return 0;
	}
	std::cout << ("\n   Process ID:") << std::hex << driver->process_id << std::endl;

	base_address = driver->find_image();

	if (!base_address) {
		std::cout << ("\n\n   Driver Error: Failed to get games base address please restart and remap driver");
		Sleep(2000);
		return 0;
	}

	std::cout << ("\n\n   Hooked to Fortnite ") << std::endl;
	std::cout << ("\n   Base Address: ") << std::hex << base_address << std::endl;

	xCreateWindow();
	xInitD3d();

	xMainLoop();
	xShutdown();

	return 0;
}



void xInitD3d()
{
	if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &p_Object)))
		exit(3);

	ZeroMemory(&d3dpp, sizeof(d3dpp));
	d3dpp.BackBufferWidth = Width;
	d3dpp.BackBufferHeight = Height;
	d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8;
	d3dpp.MultiSampleQuality = D3DMULTISAMPLE_NONE;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.EnableAutoDepthStencil = TRUE;
	d3dpp.hDeviceWindow = Window;
	d3dpp.Windowed = TRUE;

	p_Object->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, Window, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &D3dDevice);

	IMGUI_CHECKVERSION();

	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	io.DeltaTime;
	(void)io;

	ImGui_ImplWin32_Init(Window);
	ImGui_ImplDX9_Init(D3dDevice);

	XorS(font, "C:\\Windows\\Fonts\\Arial.ttf");
	io.Fonts->AddFontFromFileTTF(font.decrypt(), 13.0f, nullptr, io.Fonts->GetGlyphRangesDefault());

	p_Object->Release();
}

void aimbot(float x, float y)
{
	float ScreenCenterX = (Width / 2);
	float ScreenCenterY = (Height / 2);
	int AimSpeed = base::smoothing;
	float TargetX = 0;
	float TargetY = 0;

	if (x != 0)
	{
		if (x > ScreenCenterX)
		{
			TargetX = -(ScreenCenterX - x);
			TargetX /= AimSpeed;
			if (TargetX + ScreenCenterX > ScreenCenterX * 2) TargetX = 0;
		}

		if (x < ScreenCenterX)
		{
			TargetX = x - ScreenCenterX;
			TargetX /= AimSpeed;
			if (TargetX + ScreenCenterX < 0) TargetX = 0;
		}
	}

	if (y != 0)
	{
		if (y > ScreenCenterY)
		{
			TargetY = -(ScreenCenterY - y);
			TargetY /= AimSpeed;
			if (TargetY + ScreenCenterY > ScreenCenterY * 2) TargetY = 0;
		}

		if (y < ScreenCenterY)
		{
			TargetY = y - ScreenCenterY;
			TargetY /= AimSpeed;
			if (TargetY + ScreenCenterY < 0) TargetY = 0;
		}
	}

	mouse_event(MOUSEEVENTF_MOVE, static_cast<DWORD>(TargetX), static_cast<DWORD>(TargetY), NULL, NULL);

	return;
}



void AimAt(DWORD_PTR entity)
{
	uint64_t currentactormesh = read<uint64_t>(entity + offsets::Mesh);
	auto rootHead = GetBoneWithRotation(currentactormesh, base::hitbox);
	Vector3 rootHeadOut = ProjectWorldToScreen(rootHead);

	if (rootHeadOut.y != 0 || rootHeadOut.y != 0)
	{
		aimbot(rootHeadOut.x, rootHeadOut.y);
	}
}

RGBA FovColor = Col.purple;
RGBA SnapLineColor = Col.blue;
RGBA BoxColor = Col.red;
float FovThickness = 25;


bool isVis;

bool isVisible(DWORD_PTR mesh)
{
	if (!mesh)
		return false;
	float fLastSubmitTime = read<float>(mesh + 0x360);
	float fLastRenderTimeOnScreen = read<float>(mesh + 0x368);

	const float fVisionTick = 0.06f;
	bool bVisible = fLastRenderTimeOnScreen + fVisionTick >= fLastSubmitTime;
	return bVisible;
}


#define PI (3.141592653589793f)




void actorloop() 
{

	if (base::drawfov)
	{
		DrawCircle(ScreenCenterX, ScreenCenterY, base::fovsize, &Col.white, 150, 1);
	}
	if (base::hitboxpos == 0)
	{
		base::hitbox = 106; 
	}

	auto entityListCopy = entityList;
	float closestDistance = 280;
	DWORD_PTR closestPawn = NULL;
	std::vector<FNlEntity> tmpList;
	Uworld = read<DWORD_PTR>(base_address + OFFSET_UWORLD);
	DWORD_PTR Gameinstance = read<DWORD_PTR>(Uworld + offsets::Gameinstance);
	DWORD_PTR LocalPlayers = read<DWORD_PTR>(Gameinstance + offsets::LocalPlayers);
	Localplayer = read<DWORD_PTR>(LocalPlayers);
	PlayerController = read<DWORD_PTR>(Localplayer + offsets::PlayerController);
	LocalPawn = read<DWORD_PTR>(PlayerController + offsets::LocalPawn);
	PlayerState = read<DWORD_PTR>(LocalPawn + offsets::PlayerState);
	Rootcomp = read<DWORD_PTR>(LocalPawn + offsets::RootComponet);
	Persistentlevel = read<DWORD_PTR>(Uworld + offsets::PersistentLevel);
	DWORD ActorCount = read<DWORD>(Persistentlevel + offsets::ActorCount);
	DWORD_PTR AActors = read<DWORD_PTR>(Persistentlevel + offsets::AActor);

	for (int i = 0; i < ActorCount; i++)
	{
		uint64_t CurrentActor = read<uint64_t>(AActors + i * offsets::CurrentActor);
		uint64_t CurrentActorMesh = read<uint64_t>(CurrentActor + offsets::Mesh);
		if (read<float>(CurrentActor + offsets::Revivefromdbnotime) != 10) continue;
		int MyTeamId = read<int>(PlayerState + offsets::TeamId);
		DWORD64 otherPlayerState = read<uint64_t>(CurrentActor + offsets::PlayerState);
		int ActorTeamId = read<int>(otherPlayerState + offsets::ActorTeamId);
		if (MyTeamId == ActorTeamId) continue; 		if (CurrentActor == LocalPawn) continue;
		Vector3 Headpos = GetBoneWithRotation(CurrentActorMesh, 106);
		localactorpos = read<Vector3>(Rootcomp + offsets::LocalActorPos);
		float distance = localactorpos.Distance(Headpos) / 100.f;
		Vector3 bone0 = GetBoneWithRotation(CurrentActorMesh, 0);
		Vector3 bottom = ProjectWorldToScreen(bone0);
		Vector3 Headbox = ProjectWorldToScreen(Vector3(Headpos.x, Headpos.y, Headpos.z + 15));
		Vector3 w2shead = ProjectWorldToScreen(Headpos);

		float BoxHeight = (float)(Headbox.y - bottom.y);
		float BoxWidth = BoxHeight * 0.75f;

		float LeftX = (float)Headbox.x - (BoxWidth / 1);
		float LeftY = (float)bottom.y;

		float CornerHeight = abs(Headbox.y - bottom.y);
		float CornerWidth = CornerHeight * 0.50;
	

		if (distance < base::visdistance)
		{
			if (base::boxes)
			{

				DrawBox(Headbox.x - (CornerWidth / 2), Headbox.y, CornerWidth, CornerHeight, &Col.white);

			}

			if (base::snaplines)
			{
				DrawLine(Width / 2 - 0, Height / 2 - 0, bottom.x, bottom.y, &Col.green, 1.0);

			}
		}

		auto dx = w2shead.x - (Width / 2);
		auto dy = w2shead.y - (Height / 2);
		auto dist = sqrtf(dx * dx + dy * dy);
		if (!isVisible(CurrentActorMesh))
		{

			if (dist < base::fovsize && dist < closestDistance)
			{
				closestDistance = dist;
				closestPawn = CurrentActor;

			}
		}
		else
		{
			if (isVisible(CurrentActorMesh)) 
			{

				if (dist < base::fovsize && dist < closestDistance)
				{
					closestDistance = dist;
					closestPawn = CurrentActor;

				}
			}
		}

	}

	if (base::aimbot)
	{

		if (base::aimbot && closestPawn && GetAsyncKeyState(VK_RBUTTON) < 0)
		{
			AimAt(closestPawn);
		}
	}
	Sleep(0.2);
}



void render() 
{
	ImGui_ImplDX9_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();


	if (GetAsyncKeyState(vk_9) & 1)
	{
		ShowMenu = !ShowMenu;
	}


	if (ShowMenu)
	{


		ImGui::Begin("Updated Base | https://discord.gg/sFcDNCMJzU");


		ImGui::Checkbox("Aimbot", &base::aimbot);
		ImGui::Checkbox("Show FOV", &base::drawfov);
		ImGui::SliderInt("FOV Size", &base::fovsize, 1, 600);
		ImGui::SliderFloat("Smoothing", &base::smoothing, 1, 10);
		ImGui::Separator();
		ImGui::Checkbox("Boxes", &base::boxes);
		ImGui::Checkbox("Snaplines", &base::snaplines);




		ImGui::End();


	}

	actorloop();
	//printf("Called Actor Loop");

	ImGui::EndFrame();
	D3dDevice->SetRenderState(D3DRS_ZENABLE, false);
	D3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	D3dDevice->SetRenderState(D3DRS_SCISSORTESTENABLE, false);
	D3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);

	if (D3dDevice->BeginScene() >= 0)
	{
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
		D3dDevice->EndScene();
	}
	HRESULT result = D3dDevice->Present(NULL, NULL, NULL, NULL);

	if (result == D3DERR_DEVICELOST && D3dDevice->TestCooperativeLevel() == D3DERR_DEVICENOTRESET)
	{
		ImGui_ImplDX9_InvalidateDeviceObjects();
		D3dDevice->Reset(&d3dpp);
		ImGui_ImplDX9_CreateDeviceObjects();
	}
}


MSG Message = { NULL };

void xMainLoop()
{
	static RECT old_rc;
	ZeroMemory(&Message, sizeof(MSG));

	while (Message.message != WM_QUIT)
	{
		if (PeekMessage(&Message, Window, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}

		HWND hwnd_active = GetForegroundWindow();

		if (hwnd_active == hwnd) {
			HWND hwndtest = GetWindow(hwnd_active, GW_HWNDPREV);
			SetWindowPos(Window, hwndtest, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		}

		if (GetAsyncKeyState(0x23) & 1)
			exit(8);

		RECT rc;
		POINT xy;

		ZeroMemory(&rc, sizeof(RECT));
		ZeroMemory(&xy, sizeof(POINT));
		GetClientRect(hwnd, &rc);
		ClientToScreen(hwnd, &xy);
		rc.left = xy.x;
		rc.top = xy.y;

		ImGuiIO& io = ImGui::GetIO();
		io.ImeWindowHandle = hwnd;
		io.DeltaTime = 1.0f / 60.0f;

		POINT p;
		GetCursorPos(&p);
		io.MousePos.x = p.x - xy.x;
		io.MousePos.y = p.y - xy.y;

		if (GetAsyncKeyState(VK_LBUTTON)) {
			io.MouseDown[0] = true;
			io.MouseClicked[0] = true;
			io.MouseClickedPos[0].x = io.MousePos.x;
			io.MouseClickedPos[0].x = io.MousePos.y;
		}
		else
			io.MouseDown[0] = false;

		if (rc.left != old_rc.left || rc.right != old_rc.right || rc.top != old_rc.top || rc.bottom != old_rc.bottom)
		{
			old_rc = rc;

			Width = rc.right;
			Height = rc.bottom;

			d3dpp.BackBufferWidth = Width;
			d3dpp.BackBufferHeight = Height;
			SetWindowPos(Window, (HWND)0, xy.x, xy.y, Width, Height, SWP_NOREDRAW);
			D3dDevice->Reset(&d3dpp);
		}
		render();
	}
	ImGui_ImplDX9_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	DestroyWindow(Window);
}

LRESULT CALLBACK WinProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, Message, wParam, lParam))
		return true;

	switch (Message)
	{
	case WM_DESTROY:
		xShutdown();
		PostQuitMessage(0);
		exit(4);
		break;
	case WM_SIZE:
		if (D3dDevice != NULL && wParam != SIZE_MINIMIZED)
		{
			ImGui_ImplDX9_InvalidateDeviceObjects();
			d3dpp.BackBufferWidth = LOWORD(lParam);
			d3dpp.BackBufferHeight = HIWORD(lParam);
			HRESULT hr = D3dDevice->Reset(&d3dpp);
			if (hr == D3DERR_INVALIDCALL)
				IM_ASSERT(0);
			ImGui_ImplDX9_CreateDeviceObjects();
		}
		break;
	default:
		return DefWindowProc(hWnd, Message, wParam, lParam);
		break;
	}
	return 0;
}

void xShutdown()
{
	TriBuf->Release();
	D3dDevice->Release();
	p_Object->Release();

	DestroyWindow(Window);
	UnregisterClass("fgers", NULL);
}