#pragma once

namespace base
{
	bool aimbot = false;
	bool drawfov = false;
	float smoothing = 1;
	static int hitbox;
	static int hitboxpos = 0;
	int fovsize = 100;
	bool boxes = false;
	bool snaplines = false;
	static int visdistance = 2555;
}