#pragma once
#include <Windows.h>
#include <string>
#include <Windows.h>
#include "enc.h"
#include "lazy.h"
#include "xor.h"

void driverdetect();
void check();
void CheckDevices();
void ErasePEHeaderFromMemory();
void adbg_CrashOllyDbg();
void adbg_CheckRemoteDebuggerPresent();
void adbg_CheckWindowName();
void CheckProcessDebugObjectHandle();
void CheckProcessDebugPort();
void Debugkor();
void CheckProcessDebugFlags();
void IsDebuggerPresentPatched();
void adbg_ProcessFileName();
void ScanBlacklist();
void StopDebegger();
void AntiAttach();

bool CheckVTBlacklist(std::string id, std::string rawlinktoblacklist);
std::string pcusername();