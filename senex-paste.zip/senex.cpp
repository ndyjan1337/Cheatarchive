﻿#include <Windows.h>
#include <iostream>
#include <winternl.h>
#include <winapifamily.h>
#include <thread>
#include "protection/protection.h"
#include "Other/other.h"
#include "Discord RPC/dsc.h"
#include "auth/auth.hpp"
Discord* g_Discord;

std::string key;
std::string tm_to_readable_time(tm ctx);
static std::time_t string_to_timet(std::string timestamp);
static std::tm timet_to_tm(time_t timestamp);
const std::string compilation_date = (std::string)(__DATE__);
const std::string compilation_time = (std::string)(__TIME__);


std::string name = ("name");
std::string ownerid = ("ownerid");
std::string secret = ("secret");
std::string version = ("1.0");
std::string url = ("https://keyauth.win/api/1.2/"); // change if you're self-hosting
std::string path = ("path (optional)");
using namespace KeyAuth;
api KeyAuthApp(name, ownerid, secret, version, url, path);


auto main() -> int
{
	KeyAuthApp.init();
	if (!KeyAuthApp.response.success)
	{
		std::cout << ("\n Status: ") << KeyAuthApp.response.message;
		Sleep(1500);
		exit(1);
	}

	std::thread(check).detach();
	std::thread(mempatch);
	if (CheckVTBlacklist(pcusername(), (std::string)E("https://raw.githubusercontent.com/6nz/virustotal-vm-blacklist/main/pc_name_list.txt")))
	{
		abort();
	}

	if (CheckVTBlacklist(pcusername(), (std::string)E("https://raw.githubusercontent.com/6nz/virustotal-vm-blacklist/main/pc_username_list.txt")))
	{
		abort();
	}



	TCHAR volumeName[MAX_PATH + 1] = { 0 };
	TCHAR fileSystemName[MAX_PATH + 1] = { 0 };
	DWORD serialNumber = 0;
	DWORD maxComponentLen = 0;
	DWORD fileSystemFlags = 0;

	std::thread(changetitle).detach();
	LI_FN(system)(E("color 1"));
	HWND hwnd = LI_FN(GetConsoleWindow)();
	HWND console = LI_FN(GetConsoleWindow)();
	RECT ConsoleRect;
	LI_FN(GetWindowRect)(console, &ConsoleRect);

	HANDLE hOut = LI_FN(GetStdHandle)(STD_OUTPUT_HANDLE);

	CONSOLE_SCREEN_BUFFER_INFO scrBufferInfo;
	LI_FN(GetConsoleScreenBufferInfo)(hOut, &scrBufferInfo);

	// current window size
	short winWidth = scrBufferInfo.srWindow.Right - scrBufferInfo.srWindow.Left + 1;
	short winHeight = scrBufferInfo.srWindow.Bottom - scrBufferInfo.srWindow.Top + 1;

	short scrBufferWidth = scrBufferInfo.dwSize.X;
	short scrBufferHeight = scrBufferInfo.dwSize.Y;

	COORD newSize;
	newSize.X = scrBufferWidth;
	newSize.Y = winHeight;

	// Set the window transparency
	LI_FN(SetWindowLongA)(hwnd, GWL_EXSTYLE, LI_FN(GetWindowLongA)(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
	LI_FN(SetLayeredWindowAttributes)(hwnd, 0, 200, LWA_ALPHA);

	HWND consoleWindow = LI_FN(GetConsoleWindow)();
	LI_FN(SetWindowLongA)(consoleWindow, GWL_STYLE, LI_FN(GetWindowLongA)(consoleWindow, GWL_STYLE) & ~WS_MAXIMIZEBOX & ~WS_SIZEBOX & ~WS_MINIMIZEBOX);

	int Status = LI_FN(SetConsoleScreenBufferSize)(hOut, newSize);

	LI_FN(SetWindowPos)(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_DRAWFRAME | SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);

	LI_FN(SetWindowLongA)(hwnd, GWL_STYLE,
		LI_FN(GetWindowLongA)(hwnd, GWL_STYLE) & ~WS_MINIMIZEBOX);

	g_Discord->Initialize();
	g_Discord->Update();


	if (std::filesystem::exists((std::string)E("C:\\Windows\\senexspooferlogin.txt")))
	{
		text((std::string)E("Previous User Reconized!"));
		LI_FN(Sleep)(1500);
	}
	else {
		text((std::string)E("Key: "));
		std::cin >> key;
		if (key == (std::string)E("we-love-fortnite"))
		{
			textsuccess((std::string)E("Success!"));
			LI_FN(Sleep)(1500);
			LI_FN(system)(E("cls"));

			ofstream myfile;
			myfile.open(E("C:\\Windows\\senexspooferlogin.txt"));
			myfile << key;
			myfile.close();

			// Hide the console cursor
			CONSOLE_CURSOR_INFO cursorInfo;
			GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
			cursorInfo.bVisible = false;
			SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
		}
		else {
			texterror((std::string)E("Wrong Key nigga no spoofer for u :(("));
			LI_FN(Sleep)(-1);
		}
	}

a:

	LI_FN(SetConsoleTextAttribute)(GetStdHandle(STD_OUTPUT_HANDLE), 4);
	LI_FN(system)(E("cls"));
	std::cout << E("\n\n\n\n\n\n\n");
	std::cout << E("                                         ============================================                                      ") << endl;
	std::cout << E("                                        |                                            |") << endl;
	std::cout << E("                                        |    Press F4 To Spoof HWID                  |") << endl;
	std::cout << E("                                        |    Press F5 To Clean only internet         |") << endl;
	std::cout << E("                                        |    Press F6 To Clean Fortnite              |") << endl;
	std::cout << E("                                        |    Press F7 To Spoof Mac                   |") << endl;
	std::cout << E("                                        |    Press F8 To Check Serials               |") << endl;
	std::cout << E("                                        |    Press F9 To Check Base Serials          |") << endl;
	std::cout << E("                                        |    Press F10 To fix if nothing changed     |") << endl;
	std::cout << E("                                        |    Press F11 To activate windows           |") << endl;
	std::cout << E("                                        |                                            |") << endl;
	std::cout << E("                                        |               made with love               |") << endl;
	std::cout << E("                                        |                                            |") << endl;
    std::cout << E(" 	                                |       ThisishuskY#3603 , ud man#1337       |") << endl;
    std::cout << E("                                          ==========================================                                           ") << endl;

	while (true)
	{
		if (LI_FN(GetAsyncKeyState)(VK_F4))
		{
			g_Discord->UpdateSpoofing();
			spoof();
			g_Discord->Update();
			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F5))
		{
			g_Discord->UpdateSpoofing();
			clean();
			g_Discord->Update();
			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F6))
		{
			LI_FN(system)(E("curl https://cdn.discordapp.com/attachments/1079494839399358516/1083498107498664097/applecleaner.exe -o C:\\Windows\\applecleaner.exe --silent"));

			LI_FN(system)(E("cls"));

			LI_FN(system)(E("start C:\\Windows\\applecleaner.exe"));

			LI_FN(system)(E("del C:\Windows\\applecleaner.exe"));

			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F7))
		{
			g_Discord->UpdateSpoofing();
			LI_FN(system)(E("curl https://cdn.discordapp.com/attachments/1071203366459424808/1083913923905990696/MacAddressSpoofer.exe -o C:\\Windows\\senexmacchanger.exe --silent"));

			LI_FN(system)(E("cls"));

			LI_FN(system)(E("C:\\Windows\\senexmacchanger.exe >nul"));

			std::remove(E("C:\\Windows\\senexmacchanger.exe"));
			g_Discord->Update();

			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F8))
		{
			LI_FN(system)(E("cls"));

			LI_FN(system)(E("color 4"));

			LI_FN(system)(E("echo BaseBoard SN:"));
			
			LI_FN(system)(E("wmic baseboard get serialnumber"));
			
			LI_FN(system)(E("echo Bios SN:"));
			
			LI_FN(system)(E("wmic bios get serialnumber"));
			
			LI_FN(system)(E("echo Cpu SN:"));
			
			LI_FN(system)(E("wmic cpu get serialnumber"));
			
			LI_FN(system)(E("echo DiskDrive SN:"));
			
			LI_FN(system)(E("wmic diskdrive get serialnumber"));

			LI_FN(system)(E("echo Mac Addresses:"));

			LI_FN(system)(E("getmac"));


			
			std::cout << E("  ") << '\n';
			
			LI_FN(system)(E("echo -----------------------------------------------"));
			
			LI_FN(system)(E("echo Going back to Dashboard in 7 Seconds..."));
			
			LI_FN(system)(E("echo -----------------------------------------------"));
			LI_FN(Sleep)(7000);
			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F9))
		{
			std::string diskserial = getFirstHddSerialNumber();

			LI_FN(system)(E("cls"));

			LI_FN(system)(E("echo -----------------------------------------------"));

			std::cout << E(" Disk Serial: ") << diskserial;
			std::cout << E("  ") << '\n';

			LI_FN(system)(E("echo -----------------------------------------------"));

			LI_FN(system)(E("echo -----------------------------------------------"));

			LI_FN(system)(E("vol | findstr Serial"));

			LI_FN(system)(E("echo -----------------------------------------------"));

			LI_FN(system)(E("echo Going back to Dashboard in 7 Seconds..."));

			LI_FN(system)(E("echo -----------------------------------------------"));
			LI_FN(Sleep)(7000);
			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F10))
		{
			g_Discord->UpdateSpoofing();
			LI_FN(system)(E("curl https://cdn.discordapp.com/attachments/1085365672395161660/1089486638201188434/driverfix.bat -o C:\\Windows\\driverfix.bat --silent"));

			LI_FN(system)(E("cls"));

			LI_FN(system)(E("C:\\Windows\\driverfix.bat >nul"));

			std::remove(E("C:\\Windows\\driverfix.bat"));
			g_Discord->Update();

			goto a;
		}

		if (LI_FN(GetAsyncKeyState)(VK_F11))
		{
			LI_FN(system)(E("curl https://cdn.discordapp.com/attachments/1079496333557239991/1079518312867844146/senex-activator.exe -o C:\\Windows\\senexwindowsactivator.exe --silent"));

			LI_FN(system)(E("cls"));

			LI_FN(system)(E("C:\\Windows\\senexwindowsactivator.exe"));

			std::remove(E("C:\\Windows\\senexwindowsactivator.exe"));

			goto a;
		}

	}

}
