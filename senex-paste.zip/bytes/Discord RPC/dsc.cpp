#include "dsc.h"
#include "Includes/discord_rpc.h"
#include "../protection/enc.h"
void Discord::Initialize()
{
    DiscordEventHandlers Handle;
    memset(&Handle, 0, sizeof(Handle));
    Discord_Initialize(E("1084115737125322862"), &Handle, 1, NULL);
}

void Discord::Update()
{
    DiscordRichPresence discordPresence;
    memset(&discordPresence, 0, sizeof(discordPresence));
    discordPresence.details = E("made by ud man");
    discordPresence.state = E("In The Loader");
    discordPresence.startTimestamp = 0;
    discordPresence.largeImageKey = E("Senex Swoofer");

    discordPresence.partySize = 0;
    discordPresence.partyMax = 0;
    discordPresence.joinSecret = E("https://discord.gg/UzZ4dy2anP");
    Discord_UpdatePresence(&discordPresence);
}

void Discord::UpdateSpoofing()
{
        DiscordRichPresence discordPresence;
        memset(&discordPresence, 0, sizeof(discordPresence));
        discordPresence.details = E("made by ud man");
        discordPresence.state = E("Spoofing!");
        discordPresence.startTimestamp = 0;
        discordPresence.largeImageKey = E("Senex Swoofer");

        discordPresence.partySize = 0;
        discordPresence.partyMax = 0;
        discordPresence.joinSecret = E("https://discord.gg/UzZ4dy2anP");
        Discord_UpdatePresence(&discordPresence);
}