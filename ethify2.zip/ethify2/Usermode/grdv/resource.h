//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by project mop da floor.rc
//
#define IDI_ICON1                       101
#define IDR_ACCELERATOR1                102
#define IDB_PNG1                        103
#define IDI_ICON3                       105
#define IDB_PNG2                        106
#define IDB_PNG3                        107
#define IDB_PNG4                        108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
