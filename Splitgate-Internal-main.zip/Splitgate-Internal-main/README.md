# Splitgate-Internal

FL84 from @qu33ny ported over to Splitgate

Engine Render Menu + ESP

Update SetRotation for Aimbot to work 


UC THREAD https://www.unknowncheats.me/forum/splitgate/590637-splitgate-internal.html
